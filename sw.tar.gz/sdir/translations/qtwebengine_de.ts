<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>DownloadInterruptReason</name>
    <message>
        <source>Unknown reason or not interrupted</source>
        <translation>Unbekannter Grund oder nicht unterbrochen</translation>
    </message>
    <message>
        <source>General file operation failure</source>
        <translation>Allgemeiner Fehler bei Dateioperation</translation>
    </message>
    <message>
        <source>The file cannot be written locally, due to access restrictions</source>
        <translation>Die Datei kann aufgrund fehlender Zugriffsrechte nicht lokal gespeichert werden</translation>
    </message>
    <message>
        <source>Insufficient space on the target drive</source>
        <translation>Unzureichender Platz auf dem Ziellaufwerk</translation>
    </message>
    <message>
        <source>The directory or file name is too long</source>
        <translation>Der Name des Verzeichnisses beziehungsweise der Datei ist zu lang</translation>
    </message>
    <message>
        <source>The file size exceeds the file system limitation</source>
        <translation>Die Dateigröße überschreitet das Limit des Dateisystems</translation>
    </message>
    <message>
        <source>The file is infected with a virus</source>
        <translation>Die Datei ist mit einem Virus infiziert</translation>
    </message>
    <message>
        <source>Temporary problem (for example file in use, or too many open files)</source>
        <translation>Temporäres Problem (zum Beispiel kann die Datei gerade in Benutzung sein oder es sind zu viele Dateien geöffnet)</translation>
    </message>
    <message>
        <source>The file was blocked due to local policy</source>
        <translation>Die Datei ist aufgrund einer lokalen Richtlinie gesperrt</translation>
    </message>
    <message>
        <source>Checking the safety of the download failed due to unexpected reasons</source>
        <translation>Die Überprüfung der Sicherheit des Downloads schlug aus unerwarteten Gründen fehl</translation>
    </message>
    <message>
        <source>File seek past the end of a file (resuming previously interrupted download)</source>
        <translation>Eine Dateisuchoperation ging über das Dateiende hinaus (bei Fortsetzung eines unterbrochenen Downloads)</translation>
    </message>
    <message>
        <source>The partial file did not match the expected hash</source>
        <translation>Die angefangene Datei entspricht nicht dem gespeicherten Hash</translation>
    </message>
    <message>
        <source>General network failure</source>
        <translation>Allgemeiner Netzwerkfehler</translation>
    </message>
    <message>
        <source>The network operation has timed out</source>
        <translation>Zeitüberschreitung bei der Netzwerkoperation</translation>
    </message>
    <message>
        <source>The network connection has been terminated</source>
        <translation>Die Netzwerkverbindung wurde unterbrochen</translation>
    </message>
    <message>
        <source>The server has gone down</source>
        <translation>Der Server wurde heruntergefahren</translation>
    </message>
    <message>
        <source>The network request was invalid (for example, the URL or scheme is invalid)</source>
        <translation>Die Netzwerkanforderung war ungültig (zum Beispiel aufgrund eines ungültigen Links oder Schemas)</translation>
    </message>
    <message>
        <source>General server failure</source>
        <translation>Allgemeiner Serverfehler</translation>
    </message>
    <message>
        <source>The server does not have the requested data</source>
        <translation>Der Server verfügt nicht über die angeforderten Daten</translation>
    </message>
    <message>
        <source>The server did not authorize access to the resource</source>
        <translation>Der Server hat den Zugriff auf die Ressource nicht autorisiert</translation>
    </message>
    <message>
        <source>A problem with the server certificate occurred</source>
        <translation>Es trat ein Problem mit dem Zertifikat des Servers auf</translation>
    </message>
    <message>
        <source>Access forbidden by the server</source>
        <translation>Der Server gestattet den Zugriff nicht</translation>
    </message>
    <message>
        <source>Unexpected server response</source>
        <translation>Unerwartete Antwort des Servers</translation>
    </message>
    <message>
        <source>Download canceled by the user</source>
        <translation>Der Download wurde vom Nutzer abgebrochen</translation>
    </message>
</context>
<context>
    <name>QQuickPdfDocument</name>
    <message>
        <source>no error</source>
        <translation>kein Fehler</translation>
    </message>
    <message>
        <source>data not yet available</source>
        <translation>Daten stehen noch nicht bereit</translation>
    </message>
    <message>
        <source>file not found</source>
        <translation>Datei nicht gefunden</translation>
    </message>
    <message>
        <source>invalid file format</source>
        <translation>ungültiges Dateiformat</translation>
    </message>
    <message>
        <source>incorrect password</source>
        <translation>ungültiges Passwort</translation>
    </message>
    <message>
        <source>unsupported security scheme</source>
        <translation>nicht unterstütztes Sicherheitsverfahren</translation>
    </message>
    <message>
        <source>unknown error</source>
        <translation>unbekannter Fehler</translation>
    </message>
</context>
<context>
    <name>QQuickWebEngineView</name>
    <message>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <source>Reload and Bypass Cache</source>
        <translation>Unter Umgehung des Caches neu laden</translation>
    </message>
    <message>
        <source>Open link in this window</source>
        <translation>Link in diesem Fenster öffnen</translation>
    </message>
    <message>
        <source>Toggle Play/Pause</source>
        <translation>Abspielen/Pausieren umschalten</translation>
    </message>
    <message>
        <source>Toggle Mute</source>
        <translation>Stummschaltung umschalten</translation>
    </message>
    <message>
        <source>Close Page</source>
        <translation>Seite schließen</translation>
    </message>
    <message>
        <source>Unselect</source>
        <translation>Auswahl aufheben</translation>
    </message>
    <message>
        <source>&amp;Bold</source>
        <translation>&amp;Fett</translation>
    </message>
    <message>
        <source>&amp;Italic</source>
        <translation>&amp;Kursiv</translation>
    </message>
    <message>
        <source>&amp;Underline</source>
        <translation>&amp;Unterstrichen</translation>
    </message>
    <message>
        <source>&amp;Strikethrough</source>
        <translation>&amp;Durchgestrichen</translation>
    </message>
    <message>
        <source>Align &amp;Left</source>
        <translation>&amp;Linksbündig ausrichten</translation>
    </message>
    <message>
        <source>Align &amp;Center</source>
        <translation>&amp;Mittig ausrichten</translation>
    </message>
    <message>
        <source>Align &amp;Right</source>
        <translation>&amp;Rechtsbündig ausrichten</translation>
    </message>
    <message>
        <source>Align &amp;Justified</source>
        <translation>&amp;Blocksatz</translation>
    </message>
    <message>
        <source>&amp;Indent</source>
        <translation>&amp;Einrücken</translation>
    </message>
    <message>
        <source>&amp;Outdent</source>
        <translation>&amp;Ausrücken</translation>
    </message>
    <message>
        <source>Insert &amp;Ordered List</source>
        <translation>&amp;Nummerierte Liste einfügen</translation>
    </message>
    <message>
        <source>Insert &amp;Unordered List</source>
        <translation>&amp;Liste einfügen</translation>
    </message>
</context>
<context>
    <name>QWebEnginePage</name>
    <message>
        <source>Stop</source>
        <translation>Stop</translation>
    </message>
    <message>
        <source>Reload and Bypass Cache</source>
        <translation>Unter Umgehung des Caches neu laden</translation>
    </message>
    <message>
        <source>Toggle Play/Pause</source>
        <translation>Abspielen/Pausieren umschalten</translation>
    </message>
    <message>
        <source>Toggle Mute</source>
        <translation>Stummschaltung umschalten</translation>
    </message>
    <message>
        <source>Close Page</source>
        <translation>Seite schließen</translation>
    </message>
    <message>
        <source>Unselect</source>
        <translation>Auswahl aufheben</translation>
    </message>
    <message>
        <source>Are you sure you want to leave this page? Changes that you made may not be saved.</source>
        <translation>Möchten Sie diese Seite wirklich verlassen? Von Ihnen vorgenommene Änderungen könnten verlorengehen.</translation>
    </message>
    <message>
        <source>Open link in this window</source>
        <translation>Link in diesem Fenster öffnen</translation>
    </message>
    <message>
        <source>Open link in new background tab</source>
        <translation>Link in neuem Reiter im Hintergrund öffnen</translation>
    </message>
    <message>
        <source>&amp;Bold</source>
        <translation>&amp;Fett</translation>
    </message>
    <message>
        <source>&amp;Italic</source>
        <translation>&amp;Kursiv</translation>
    </message>
    <message>
        <source>&amp;Underline</source>
        <translation>&amp;Unterstrichen</translation>
    </message>
    <message>
        <source>&amp;Strikethrough</source>
        <translation>&amp;Durchgestrichen</translation>
    </message>
    <message>
        <source>Align &amp;Left</source>
        <translation>&amp;Linksbündig ausrichten</translation>
    </message>
    <message>
        <source>Align &amp;Center</source>
        <translation>&amp;Mittig ausrichten</translation>
    </message>
    <message>
        <source>Align &amp;Right</source>
        <translation>&amp;Rechtsbündig ausrichten</translation>
    </message>
    <message>
        <source>Align &amp;Justified</source>
        <translation>&amp;Blocksatz</translation>
    </message>
    <message>
        <source>&amp;Indent</source>
        <translation>&amp;Einrücken</translation>
    </message>
    <message>
        <source>&amp;Outdent</source>
        <translation>&amp;Ausrücken</translation>
    </message>
    <message>
        <source>Insert &amp;Ordered List</source>
        <translation>&amp;Nummerierte Liste einfügen</translation>
    </message>
    <message>
        <source>Insert &amp;Unordered List</source>
        <translation>&amp;Liste einfügen</translation>
    </message>
</context>
<context>
    <name>RenderViewContextMenuQt</name>
    <message>
        <source>Back</source>
        <translation>Zurück</translation>
    </message>
    <message>
        <source>Forward</source>
        <translation>Vorwärts</translation>
    </message>
    <message>
        <source>Reload</source>
        <translation>Neu laden</translation>
    </message>
    <message>
        <source>Cut</source>
        <translation>Ausschneiden</translation>
    </message>
    <message>
        <source>Copy</source>
        <translation>Kopieren</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Einfügen</translation>
    </message>
    <message>
        <source>Undo</source>
        <translation>Rückgängig</translation>
    </message>
    <message>
        <source>Redo</source>
        <translation>Wiederholen</translation>
    </message>
    <message>
        <source>Select all</source>
        <translation>Alles auswählen</translation>
    </message>
    <message>
        <source>Paste and match style</source>
        <translation>Einfügen und Stil anpassen</translation>
    </message>
    <message>
        <source>Open link in new window</source>
        <translation>Link in neuem Fenster öffnen</translation>
    </message>
    <message>
        <source>Open link in new tab</source>
        <translation>Link in neuem Reiter öffnen</translation>
    </message>
    <message>
        <source>Copy link address</source>
        <translation>Adresse des Links kopieren</translation>
    </message>
    <message>
        <source>Save link</source>
        <translation>Link speichern</translation>
    </message>
    <message>
        <source>Copy image</source>
        <translation>Bild kopieren</translation>
    </message>
    <message>
        <source>Copy image address</source>
        <translation>Adresse des Bildes kopieren</translation>
    </message>
    <message>
        <source>Save image</source>
        <translation>Bild speichern</translation>
    </message>
    <message>
        <source>Copy media address</source>
        <translation>Medienadresse kopieren</translation>
    </message>
    <message>
        <source>Show controls</source>
        <translation>Steuerelemente anzeigen</translation>
    </message>
    <message>
        <source>Loop</source>
        <translation>Dauerschleife</translation>
    </message>
    <message>
        <source>Save media</source>
        <translation>Medien speichern</translation>
    </message>
    <message>
        <source>Inspect</source>
        <translation>Inspizieren</translation>
    </message>
    <message>
        <source>Exit full screen</source>
        <translation>Vollbildmodus beenden</translation>
    </message>
    <message>
        <source>Save page</source>
        <translation>Seite speichern</translation>
    </message>
    <message>
        <source>View page source</source>
        <translation>Quelltext der Seite anzeigen</translation>
    </message>
</context>
<context>
    <name>UIDelegatesManager</name>
    <message>
        <source>Javascript Alert - %1</source>
        <translation>Javascript-Warnung - %1</translation>
    </message>
    <message>
        <source>Javascript Confirm - %1</source>
        <translation>Javascript-Bestätigung - %1</translation>
    </message>
    <message>
        <source>Javascript Prompt - %1</source>
        <translation>Javascript-Abfrage - %1</translation>
    </message>
    <message>
        <source>Are you sure you want to leave this page?</source>
        <translation>Möchten Sie diese Seite wirklich verlassen?</translation>
    </message>
    <message>
        <source>Changes that you made may not be saved.</source>
        <translation>Ihre ausstehenden Änderungen werden eventuell nicht gesichert.</translation>
    </message>
    <message>
        <source>Connect to proxy &quot;%1&quot; using:</source>
        <translation>Verbinde zu Proxy &quot;%1&quot; unter Verwendung von:</translation>
    </message>
    <message>
        <source>Enter username and password for &quot;%1&quot; at %2://%3</source>
        <translation>Geben Sie Nutzername und Passwort für &quot;%1&quot; auf %2://%3 ein</translation>
    </message>
</context>
<context>
    <name>WebContentsAdapter</name>
    <message>
        <source>HTTP-POST data can only be sent over HTTP(S) protocol</source>
        <translation>HTTP-POST-Daten können nur über das HTTP(S)-Protokoll versendet werden</translation>
    </message>
</context>
<context>
    <name>FilePickerController</name>
    <message>
        <source>Accepted types (%1)</source>
        <translation>Zulässige Typen (%1)</translation>
    </message>
</context>
<context>
    <name>QWebEngineView</name>
    <message>
        <source>Select folder to upload</source>
        <translation>Verzeichnis zum Hochladen</translation>
    </message>
</context>
<context>
    <name>AlertDialog</name>
    <message>
        <source>Alert Dialog</source>
        <translation>Benachrichtigungsdialog</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
</context>
<context>
    <name>AuthenticationDialog</name>
    <message>
        <source>Authentication Required</source>
        <translation>Authentifizierung erforderlich</translation>
    </message>
    <message>
        <source>Username:</source>
        <translation>Benutzername:</translation>
    </message>
    <message>
        <source>Password:</source>
        <translation>Passwort:</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
    <message>
        <source>Log In</source>
        <translation>Einloggen</translation>
    </message>
</context>
<context>
    <name>ColorDialog</name>
    <message>
        <source>Color Picker Dialog</source>
        <translation>Farbauswahldialog</translation>
    </message>
    <message>
        <source>Copy color</source>
        <translation>Farbe kopieren</translation>
    </message>
    <message>
        <source>Paste</source>
        <translation>Einfügen</translation>
    </message>
    <message>
        <source>Apply</source>
        <translation>Anwenden</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
</context>
<context>
    <name>ConfirmDialog</name>
    <message>
        <source>Confirm Dialog</source>
        <translation>Bestätigungsdialog</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
</context>
<context>
    <name>PromptDialog</name>
    <message>
        <source>Prompt Dialog</source>
        <translation>Abfragedialog</translation>
    </message>
    <message>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <source>Cancel</source>
        <translation>Abbrechen</translation>
    </message>
</context>
</TS>
